package com.example.ordertracking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdertrackingApplicationTests {

	@Test
	void contextLoads() {
	}

}
