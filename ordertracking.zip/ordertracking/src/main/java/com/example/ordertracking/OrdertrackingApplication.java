package com.example.ordertracking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdertrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrdertrackingApplication.class, args);
	}

}
